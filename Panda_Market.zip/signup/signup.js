document.addEventListener("DOMContentLoaded", () => {
  const emailInput       = document.getElementById('userEmail');
  const passwordInput    = document.getElementById('password');
  const passwordInput_re = document.getElementById('password_re');
  const toggleIcon       = document.getElementById('togglepassword');
  const toggleIcon_re    = document.getElementById('togglepassword_re');

  const emailError       = document.getElementById('email-error');
  const passwordError    = document.getElementById('password-error');
  const passwordReError  = document.getElementById('password-re-error');

  const loginButton      = document.querySelector('.button_layout button');
  const modal            = document.getElementById('customModal');
  const modalMessage     = document.getElementById('modalMessage');
  const modalClose       = document.getElementById('closeModal');

  const USER_DATA = [
    { email: 'codeit1@codeit.com', password: "codeit101!" },
    { email: 'codeit2@codeit.com', password: "codeit202!" },
    { email: 'codeit3@codeit.com', password: "codeit303!" },
    { email: 'codeit4@codeit.com', password: "codeit404!" },
    { email: 'codeit5@codeit.com', password: "codeit505!" },
    { email: 'codeit6@codeit.com', password: "codeit606!" },
  ];

  // — 비밀번호 보기 토글 (기존)
  toggleIcon.addEventListener('click', () => {
    const isPassword = passwordInput.type === 'password';
    passwordInput.type = isPassword ? 'text' : 'password';
    toggleIcon.src   = isPassword ? '../images/visibility_on.png' : '../images/visibility_off.png';
  });

  toggleIcon_re.addEventListener('click', () => {
    const isPassword = passwordInput_re.type === 'password';
    passwordInput_re.type = isPassword ? 'text' : 'password';
    toggleIcon_re.src     = isPassword ? '../images/visibility_on.png' : '../images/visibility_off.png';
  });

  // — 이메일 유효성 검사 (기존)
  function validateEmail() {
    const value = emailInput.value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!value) {
      showEmailError("이메일을 입력해주세요.");
      return false;
    } else if (!emailRegex.test(value)) {
      showEmailError("잘못된 이메일 형식입니다.");
      return false;
    }
    hideEmailError();
    return true;
  }

  function showEmailError(message) {
    emailError.textContent = message;
    emailError.classList.remove('hidden');
    emailInput.classList.add('invalid');
  }
  function hideEmailError() {
    emailError.classList.add('hidden');
    emailInput.classList.remove('invalid');
  }

  // — 비밀번호 유효성 검사 (기존)
  function validatePassword() {
    const value = passwordInput.value;
    if (!value) {
      showPasswordError("비밀번호를 입력해주세요.");
      return false;
    } else if (value.length < 8) {
      showPasswordError("비밀번호를 8자 이상 입력해주세요.");
      return false;
    }
    hidePasswordError();
    return true;
  }

  function showPasswordError(message) {
    passwordError.textContent = message;
    passwordError.classList.remove('hidden');
    passwordInput.classList.add('invalid');
  }
  function hidePasswordError() {
    passwordError.classList.add('hidden');
    passwordInput.classList.remove('invalid');
  }

  // — 비밀번호 확인 유효성 검사 (추가)
  function validatePasswordRe() {
    const value = passwordInput_re.value;
    if (!value) {
      showPasswordReError("비밀번호를 다시 입력해주세요.");
      return false;
    } else if (value !== passwordInput.value) {
      showPasswordReError("비밀번호가 일치하지 않습니다.");
      return false;
    }
    hidePasswordReError();
    return true;
  }

  function showPasswordReError(message) {
    passwordReError.textContent = message;
    passwordReError.classList.remove('hidden');
    passwordInput_re.classList.add('invalid');
  }
  function hidePasswordReError() {
    passwordReError.classList.add('hidden');
    passwordInput_re.classList.remove('invalid');
  }

  // — 버튼 활성화 관리 (수정)
  function updateLoginButtonState() {
    const emailOk   = validateEmail();
    const passOk    = validatePassword();
    const passReOk  = validatePasswordRe();
    const isValid   = emailOk && passOk && passReOk;

    loginButton.disabled = !isValid;
    loginButton.style.cursor  = isValid ? 'pointer' : 'not-allowed';
    loginButton.style.opacity = isValid ? '1' : '0.5';
    if (isValid) {
      loginButton.classList.add('active');
    } else {
      loginButton.classList.remove('active');
    }
  }

  // — 이벤트 리스너 (수정)
  emailInput.addEventListener('blur', () => { validateEmail();    updateLoginButtonState(); });
  passwordInput.addEventListener('blur', () => { validatePassword(); updateLoginButtonState(); });
  passwordInput_re.addEventListener('blur', () => { validatePasswordRe(); updateLoginButtonState(); });

  emailInput.addEventListener('input', () => { hideEmailError();    updateLoginButtonState(); });
  passwordInput.addEventListener('input', () => { hidePasswordError(); updateLoginButtonState(); });
  passwordInput_re.addEventListener('input', () => { hidePasswordReError(); updateLoginButtonState(); });

  // — 모달 열기/닫기 및 로그인 처리 (기존)
  function showModal(message) {
    modalMessage.textContent = message;
    modal.classList.remove('hidden');
  }
  modalClose.addEventListener('click', () => {
    modal.classList.add('hidden');
    modalMessage.textContent = "";
    hideEmailError();
    hidePasswordError();
    hidePasswordReError();
  });

  loginButton.addEventListener('click', (e) => {
    e.preventDefault();
    if (!validateEmail() || !validatePassword() || !validatePasswordRe()) return;

    const inputEmail    = emailInput.value.trim();
    const inputPassword = passwordInput.value;
    const user = USER_DATA.find(u => u.email === inputEmail);

    if (!user) {
      showModal("사용 중인 이메일입니다.");
      return;
    }
    if (user.password !== inputPassword) {
      showModal("비밀번호가 일치하지 않습니다.");
      return;
    }

    showModal("로그인 성공!");
    setTimeout(() => {
      modal.classList.add('hidden');
      window.location.href = "../items.html";
    }, 1000);
  });
});
