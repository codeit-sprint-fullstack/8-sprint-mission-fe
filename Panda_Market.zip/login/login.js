document.addEventListener("DOMContentLoaded", () => {
  const emailInput = document.getElementById('userEmail');
  const passwordInput = document.getElementById('password');
  const toggleIcon = document.getElementById('togglepassword');
  const emailError = document.getElementById('email-error');
  const passwordError = document.getElementById('password-error');
  const loginButton = document.querySelector('.button_layout button');
  const modal = document.getElementById('customModal');
  const modalMessage = document.getElementById('modalMessage');
  const modalClose = document.getElementById('closeModal');

  const USER_DATA = [
    { email: 'codeit1@codeit.com', password: "codeit101!" },
    { email: 'codeit2@codeit.com', password: "codeit202!" },
    { email: 'codeit3@codeit.com', password: "codeit303!" },
    { email: 'codeit4@codeit.com', password: "codeit404!" },
    { email: 'codeit5@codeit.com', password: "codeit505!" },
    { email: 'codeit6@codeit.com', password: "codeit606!" },
  ];

  // 비밀번호 보기 토글
  toggleIcon.addEventListener('click', () => {
    const isPassword = passwordInput.type === 'password';
    passwordInput.type = isPassword ? 'text' : 'password';
    toggleIcon.src = isPassword ? '../images/visibility_on.png' : '../images/visibility_off.png';
  });

  // 유효성 검사
  function validateEmail() {
    const value = emailInput.value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!value) {
      showEmailError("이메일을 입력해주세요.");
      return false;
    } else if (!emailRegex.test(value)) {
      showEmailError("잘못된 이메일 형식입니다");
      return false;
    } else {
      hideEmailError();
      return true;
    }
  }

  function validatePassword() {
    const value = passwordInput.value;
    if (!value) {
      showPasswordError("비밀번호를 입력해주세요.");
      return false;
    } else if (value.length < 8) {
      showPasswordError("비밀번호를 8자 이상 입력해주세요.");
      return false;
    } else {
      hidePasswordError();
      return true;
    }
  }

  function showEmailError(message) {
    emailError.textContent = message;
    emailError.classList.remove('hidden');
    emailInput.classList.add('invalid');
  }

  function hideEmailError() {
    emailError.classList.add('hidden');
    emailInput.classList.remove('invalid');
  }

  function showPasswordError(message) {
    passwordError.textContent = message;
    passwordError.classList.remove('hidden');
    passwordInput.classList.add('invalid');
  }

  function hidePasswordError() {
    passwordError.classList.add('hidden');
    passwordInput.classList.remove('invalid');
  }

  // 버튼 활성화 관리
  function updateLoginButtonState() {
    const isValid = validateEmail() && validatePassword();
    loginButton.disabled = !isValid;
    loginButton.style.cursor = isValid ? 'pointer' : 'not-allowed';
    loginButton.style.opacity = isValid ? '1' : '0.5';
    if (isValid) {
      loginButton.classList.add('active');
    } else {
      loginButton.classList.remove('active');
    }
  }

  emailInput.addEventListener('blur', () => {
    validateEmail();
    updateLoginButtonState();
  });

  passwordInput.addEventListener('blur', () => {
    validatePassword();
    updateLoginButtonState();
  });

  emailInput.addEventListener('input', () => {
    hideEmailError();
    updateLoginButtonState();
  });

  passwordInput.addEventListener('input', () => {
    hidePasswordError();
    updateLoginButtonState();
  });

  // 모달 열기
  function showModal(message) {
    modalMessage.textContent = message;
    modal.classList.remove('hidden');
  }

  // 모달 닫기
  modalClose.addEventListener('click', () => {
    modal.classList.add('hidden');
    modalMessage.textContent = "";
    hideEmailError();
    hidePasswordError();
  });

  // 로그인 버튼 클릭 이벤트
  loginButton.addEventListener('click', (e) => {
    e.preventDefault();

    const isEmailValid = validateEmail();
    const isPasswordValid = validatePassword();
    if (!isEmailValid || !isPasswordValid) return;

    const inputEmail = emailInput.value.trim();
    const inputPassword = passwordInput.value;
    const user = USER_DATA.find(user => user.email === inputEmail);

    if (!user || user.password !== inputPassword) {
      showModal("비밀번호가 일치하지 않습니다.");
      return;
    }

    // 로그인 성공
    showModal("로그인 성공!");
    setTimeout(() => {
      modal.classList.add('hidden');
      window.location.href = "../items.html";
    }, 1000);
  });
});
